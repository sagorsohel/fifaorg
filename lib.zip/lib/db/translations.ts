import { LanguageCode } from "../i18n"

export const teamTranslations: Record<string, Partial<Record<LanguageCode, string>>> = {
  "Mexico": {
    en: "Mexico", "en-us": "Mexico", ar: "المكسيك", az: "Meksika", bn: "মেক্সিকো", cs: "Mexiko", da: "Mexico", de: "Mexiko", el: "Μεξικό", es: "México",
    "es-la": "México", fr: "Mexique", hi: "मेक्सिको", hr: "Meksiko", hu: "Mexikó", id: "Meksiko", it: "Messico", nl: "Mexico", no: "Mexico", pl: "Meksyk",
    pt: "México", "pt-pt": "México", ro: "Mexic", ru: "Мексика", sk: "Mexiko", sl: "Mehika", sr: "Мексико", sv: "Mexiko", tr: "Meksika", zh: "墨西哥"
  },
  "South Africa": {
    en: "South Africa", "en-us": "South Africa", ar: "جنوب أفريقيا", az: "Cənubi Afrika", bn: "দক্ষিণ আফ্রিকা", cs: "Jihoafrická republika", da: "Sydafrika", de: "Südafrika", el: "Νότια Αφρική", es: "Sudáfrica",
    "es-la": "Sudáfrica", fr: "Afrique du Sud", hi: "दक्षिण अफ्रीका", hr: "Južna Afrika", hu: "Dél-afrikai Közt้ารส", id: "Afrika Selatan", it: "Sudafrica", nl: "Zuid-Afrika", no: "Sør-Afrika", pl: "Południowa Afryka",
    pt: "África do Sul", "pt-pt": "África do Sul", ro: "Africa de Sud", ru: "Южная Африка", sk: "Južná Afrika", sl: "Južna Afrika", sr: "Јужна Африка", sv: "Sydafrika", tr: "Güney Afrika", zh: "南非"
  },
  "South Korea": {
    en: "South Korea", "en-us": "South Korea", ar: "كوريا الجنوبية", az: "Cənubi Koreya", bn: "দক্ষিণ কোরিয়া", cs: "Jižní Korea", da: "Sydkorea", de: "Südkorea", el: "Νότια Κορέα", es: "Corea del Sur",
    "es-la": "Corea del Sur", fr: "Corée du Sud", hi: "दक्षिण कोरिया", hr: "Južna Koreja", hu: "Dél-Korea", id: "Korea Selatan", it: "Corea del Sud", nl: "Zuid-Korea", no: "Sør-Korea", pl: "Korea Południowa",
    pt: "Coreia do Sul", "pt-pt": "Coreia do Sul", ro: "Coreea de Sud", ru: "Южная Корея", sk: "Južná Kórea", sl: "Južna Kórea", sr: "Јужна Кореја", sv: "Sydkorea", tr: "Güney Kore", zh: "韩国"
  },
  "Czech Republic": {
    en: "Czech Republic", "en-us": "Czechia", ar: "جمهورية التشيك", az: "Çexiya", bn: "চেক প্রজাতন্ত্র", cs: "Česká republika", da: "Tjekkiet", de: "Tschechien", el: "Τσεχία", es: "República Checa",
    "es-la": "República Checa", fr: "République Tchèque", hi: "चेक गणराज्य", hr: "Češka", hu: "Csehország", id: "Ceko", it: "Repubblica Ceca", nl: "Tsjechië", no: "Tsjekkia", pl: "Czechy",
    pt: "República Checa", "pt-pt": "República Checa", ro: "Cehia", ru: "Чехия", sk: "Česká republika", sl: "Češka", sr: "Чешка Република", sv: "Tjeckien", tr: "Çekya", zh: "捷克"
  },
  "Canada": {
    en: "Canada", "en-us": "Canada", ar: "كندا", az: "Kanada", bn: "কানাডা", cs: "Kanada", da: "Kanada", de: "Kanada", el: "Καναδάς", es: "Canadá",
    "es-la": "Canadá", fr: "Canada", hi: "कनाडा", hr: "Kanada", hu: "Kanada", id: "Kanada", it: "Canada", nl: "Canada", no: "Canada", pl: "Kanada",
    pt: "Canadá", "pt-pt": "Canadá", ro: "Canada", ru: "Канада", sk: "Kanada", sl: "Kanada", sr: "Канада", sv: "Kanada", tr: "Kanada", zh: "加拿大"
  },
  "Bosnia and Herzegovina": {
    en: "Bosnia and Herzegovina", "en-us": "Bosnia & Herzegovina", ar: "البوسنة والهرسك", az: "Bosniya və Herseqovina", bn: "বসনিয়া ও হার্জেগোভিনা", cs: "Bosna a Hercegovina", da: "Bosnien-Hercegovina", de: "Bosnien und Herzegowina", el: "Βοσνία και Ερζεγοβίνη", es: "Bosnia y Herzegovina",
    "es-la": "Bosnia y Herzegovina", fr: "Bosnie-Herzégovine", hi: "बोस्निया और हर्ज़ेगोविना", hr: "Bosna i Hercegovina", hu: "Bosznia-Hercegovina", id: "Bosnia dan Herzegovina", it: "Bosnia ed Erzegovina", nl: "Bosnië-Herzegovina", no: "Bosnia-Hercegovina", pl: "Bośnia i Hercegowina",
    pt: "Bósnia e Herzegovina", "pt-pt": "Bósnia e Herzegovina", ro: "Bosnia și Herțegovina", ru: "Босния и Герцеговина", sk: "Bosna a Hercegovina", sl: "Bosna in Hercegovina", sr: "Босна и Херцеговина", sv: "Bosnien och Hercegovina", tr: "Bosna-Hersek", zh: "波黑"
  },
  "Qatar": {
    en: "Qatar", "en-us": "Qatar", ar: "قطر", az: "Qətər", bn: "কাতার", cs: "Katar", da: "Qatar", de: "Katar", el: "Κατάρ", es: "Catar",
    "es-la": "Catar", fr: "Qatar", hi: "क़तर", hr: "Katar", hu: "Katar", id: "Qatar", it: "Qatar", nl: "Qatar", no: "Qatar", pl: "Katar",
    pt: "Catar", "pt-pt": "Catar", ro: "Qatar", ru: "Катар", sk: "Katar", sl: "Katar", sr: "Катар", sv: "Qatar", tr: "Katar", zh: "卡塔尔"
  },
  "Switzerland": {
    en: "Switzerland", "en-us": "Switzerland", ar: "سويسرا", az: "İsveçrə", bn: "সুইজারল্যান্ড", cs: "Švýcarsko", da: "Schweiz", de: "Schweiz", el: "Ελβετία", es: "Suiza",
    "es-la": "Suiza", fr: "Suisse", hi: "स्виट्जरलैंड", hr: "Švicarska", hu: "Svájc", id: "Swiss", it: "Svizzera", nl: "Zwitserland", no: "Sveits", pl: "Szwajcaria",
    pt: "Suíça", "pt-pt": "Suíça", ro: "Elveția", ru: "Швейцария", sk: "Švajčiarsko", sl: "Švica", sr: "Швајцарска", sv: "Schweiz", tr: "İsviçre", zh: "瑞士"
  },
  "Brazil": {
    en: "Brazil", "en-us": "Brazil", ar: "البرازيل", az: "Braziliya", bn: "ব্রাজিল", cs: "Brazílie", da: "Brasilien", de: "Brasilien", el: "Βραζιλία", es: "Brasil",
    "es-la": "Brasil", fr: "Brésil", hi: "ब्राज़ील", hr: "Brazil", hu: "Brazília", id: "Brasil", it: "Brasile", nl: "Brazilië", no: "Brasil", pl: "Brazylia",
    pt: "Brasil", "pt-pt": "Brasil", ro: "Brazilia", ru: "Бразилия", sk: "Brazília", sl: "Brazilija", sr: "Бразил", sv: "Brasilien", tr: "Brezilya", zh: "巴西"
  },
  "Morocco": {
    en: "Morocco", "en-us": "Morocco", ar: "المغرب", az: "Mərakeş", bn: "মরক্কো", cs: "Maroko", da: "Marokko", de: "Marokko", el: "Μαρόκο", es: "Marruecos",
    "es-la": "Marruecos", fr: "Maroc", hi: "मोरक्को", hr: "Maroko", hu: "Marokkó", id: "Maroko", it: "Marocco", nl: "Marokko", no: "Marokko", pl: "Maroko",
    pt: "Marrocos", "pt-pt": "Marrocos", ro: "Maroc", ru: "Марокко", sk: "Maroko", sl: "Maroko", sr: "Мароко", sv: "Marocko", tr: "Fas", zh: "摩洛哥"
  },
  "Haiti": {
    en: "Haiti", "en-us": "Haiti", ar: "هايتي", az: "Haiti", bn: "হাইতি", cs: "Haiti", da: "Haiti", de: "Haiti", el: "Αϊτή", es: "Haití",
    "es-la": "Haití", fr: "Haïti", hi: "हैती", hr: "Haiti", hu: "Haiti", id: "Haiti", it: "Haiti", nl: "Haïti", no: "Haiti", pl: "Haiti",
    pt: "Haiti", "pt-pt": "Haiti", ro: "Haiti", ru: "Гаити", sk: "Haiti", sl: "Haiti", sr: "Хаити", sv: "Haiti", tr: "Haiti", zh: "海地"
  },
  "Scotland": {
    en: "Scotland", "en-us": "Scotland", ar: "أسكتلندا", az: "Şotlandiya", bn: "স্কটল্যান্ড", cs: "Skotsko", da: "Skotland", de: "Schottland", el: "Σκωτία", es: "Escocia",
    "es-la": "Escocia", fr: "Écosse", hi: "स्कॉटलैंड", hr: "Škotska", hu: "Skócia", id: "Skotlandia", it: "Scozia", nl: "Schotland", no: "Skottland", pl: "Szkocja",
    pt: "Escócia", "pt-pt": "Escócia", ro: "Scoția", ru: "Шотландия", sk: "Skótsko", sl: "Škotska", sr: "Шкотска", sv: "Skottland", tr: "İskoçya", zh: "苏格兰"
  },
  "United States": {
    en: "United States", "en-us": "United States", ar: "الولايات المتحدة", az: "ABŞ", bn: "মার্কিন যুক্তরাষ্ট্র", cs: "Spojené státy", da: "USA", de: "USA", el: "Ηνωμένες Πολιτείες", es: "Estados Unidos",
    "es-la": "Estados Unidos", fr: "États-Unis", hi: "संयुक्त राज्य अमेरिका", hr: "SAD", hu: "Amerikai Egyesült Államok", id: "Amerika Serikat", it: "Stati Uniti", nl: "Verenigde Staten", no: "USA", pl: "Stany Zjednoczone",
    pt: "Estados Unidos", "pt-pt": "Estados Unidos", ro: "Statele Unite", ru: "США", sk: "Spojené štáty", sl: "Združene države Amerike", sr: "Сједињене Америчке Државе", sv: "USA", tr: "Amerika Birleşik Devletleri", zh: "美国"
  },
  "Paraguay": {
    en: "Paraguay", "en-us": "Paraguay", ar: "باراغواي", az: "Paraqvay", bn: "প্যারাগুয়ে", cs: "Paraguay", da: "Paraguay", de: "Paraguay", el: "Παραγουάη", es: "Paraguay",
    "es-la": "Paraguay", fr: "Paraguay", hi: "पराग्वे", hr: "Paragvaj", hu: "Paraguay", id: "Paraguay", it: "Paraguay", nl: "Paraguay", no: "Paraguay", pl: "Paragwaj",
    pt: "Paraguai", "pt-pt": "Paraguai", ro: "Paraguay", ru: "Парагвай", sk: "Paraguaj", sl: "Paragvaj", sr: "Парагвај", sv: "Paraguay", tr: "Paraguay", zh: "巴拉圭"
  },
  "Australia": {
    en: "Australia", "en-us": "Australia", ar: "أستراليا", az: "Avstraliya", bn: "অস্ট্রেলিয়া", cs: "Austrálie", da: "Australien", de: "Australien", el: "Αυστρία", es: "Australia",
    "es-la": "Australia", fr: "Australie", hi: "ऑस्ट्रेलिया", hr: "Australija", hu: "Ausztrália", id: "Australia", it: "Australia", nl: "Australië", no: "Australia", pl: "Australia",
    pt: "Austrália", "pt-pt": "Austrália", ro: "Australia", ru: "Австралия", sk: "Austrália", sl: "Avstralija", sr: "Аустралија", sv: "Australien", tr: "Avustralya", zh: "澳大利亚"
  },
  "Turkey": {
    en: "Turkey", "en-us": "Turkey", ar: "تركيا", az: "Türkiyə", bn: "তুরস্ক", cs: "Turecko", da: "Tyrkiet", de: "Türkei", el: "Τουρκία", es: "Turquía",
    "es-la": "Turquía", fr: "Turquie", hi: "तुर्की", hr: "Turska", hu: "Törökország", id: "Turki", it: "Turchia", nl: "Turkije", no: "Tyrkia", pl: "Turcja",
    pt: "Turquia", "pt-pt": "Turquia", ro: "Turcia", ru: "Турция", sk: "Turecko", sl: "Turčija", sr: "Турска", sv: "Turkiet", tr: "Türkiye", zh: "土耳其"
  },
  "Germany": {
    en: "Germany", "en-us": "Germany", ar: "ألمانيا", az: "Almaniya", bn: "জার্মানি", cs: "Německo", da: "Tyskland", de: "Deutschland", el: "Γερμανία", es: "Alemania",
    "es-la": "Alemania", fr: "Allemagne", hi: "जर्मनी", hr: "Njemačka", hu: "Németország", id: "Jerman", it: "Germania", nl: "Duitsland", no: "Tyskland", pl: "Niemcy",
    pt: "Alemanha", "pt-pt": "Alemanha", ro: "Germania", ru: "Германия", sk: "Nemecko", sl: "Nemčija", sr: "Немачка", sv: "Tyskland", tr: "Almanya", zh: "德国"
  },
  "Curaçao": {
    en: "Curaçao", "en-us": "Curaçao", ar: "كوراساو", az: "Kürasao", bn: "কুরাসাও", cs: "Curaçao", da: "Curaçao", de: "Curaçao", el: "Κουρασάο", es: "Curaçao",
    "es-la": "Curaçao", fr: "Curaçao", hi: "कुराकाओ", hr: "Curaçao", hu: "Curaçao", id: "Curaçao", it: "Curaçao", nl: "Curaçao", no: "Curaçao", pl: "Curaçao",
    pt: "Curaçao", "pt-pt": "Curaçao", ro: "Curaçao", ru: "Кюрасао", sk: "Curaçao", sl: "Curaçao", sr: "Кирасао", sv: "Curaçao", tr: "Curaçao", zh: "库拉索"
  },
  "Ivory Coast": {
    en: "Ivory Coast", "en-us": "Ivory Coast", ar: "ساحل العاج", az: "Fil Dişi Sahili", bn: "আইভরি কোস্ট", cs: "Pobřeží slonoviny", da: "Elfenbenskysten", de: "Elfenbeinküste", el: "Ακτή Ελεφαντοστού", es: "Costa de Marfil",
    "es-la": "Costa de Marfil", fr: "Côte d'Ivoire", hi: "आइवरी कोस्ट", hr: "Obala Bjelokosti", hu: "Elefántcsontpart", id: "Pantai Gading", it: "Costa d'Avorio", nl: "Ivoorkust", no: "Elfenbenskysten", pl: "Wybrzeże Kości Słoniowej",
    pt: "Costa do Marfim", "pt-pt": "Costa do Marfim", ro: "Coasta de Fildeș", ru: "Кот-д'Ивуар", sk: "Pobrežie Slonoviny", sl: "Slonokoščena obala", sr: "Обала Слоноваче", sv: "Elfenbenskusten", tr: "Fildişi Sahili", zh: "科特迪瓦"
  },
  "Ecuador": {
    en: "Ecuador", "en-us": "Ecuador", ar: "الإكوادور", az: "Ekvador", bn: "ইকুয়েডর", cs: "Ekvádor", da: "Ecuador", de: "Ecuador", el: "Ισημερινός", es: "Ecuador",
    "es-la": "Ecuador", fr: "Équateur", hi: "इक्वाडोर", hr: "Ekvador", hu: "Ecuador", id: "Ekuador", it: "Ecuador", nl: "Ecuador", no: "Ecuador", pl: "Ekwador",
    pt: "Equador", "pt-pt": "Equador", ro: "Ecuador", ru: "Эквадор", sk: "Ekvádor", sl: "Ekvador", sr: "Еквадор", sv: "Ecuador", tr: "Ekvador", zh: "厄瓜多尔"
  },
  "Netherlands": {
    en: "Netherlands", "en-us": "Netherlands", ar: "هولندا", az: "Niderland", bn: "নেদারল্যান্ডস", cs: "Nizozemsko", da: "Holland", de: "Niederlande", el: "Ολλανδία", es: "Países Bajos",
    "es-la": "Países Bajos", fr: "Pays-Bas", hi: "नेदरलैंड्स", hr: "Nizozemska", hu: "Hollandia", id: "Belanda", it: "Paesi Bassi", nl: "Nederland", no: "Nederland", pl: "Holandia",
    pt: "Países Bajos", "pt-pt": "Países Baixos", ro: "Țările de Jos", ru: "Нидерланды", sk: "Holandsko", sl: "Nizozemska", sr: "Холандија", sv: "Nederländerna", tr: "Hollanda", zh: "荷兰"
  },
  "Japan": {
    en: "Japan", "en-us": "Japan", ar: "اليابان", az: "Yaponiya", bn: "জাপান", cs: "Japonsko", da: "Japan", de: "Japan", el: "Ιαπωνία", es: "Japón",
    "es-la": "Japón", fr: "Japon", hi: "जापान", hr: "Japan", hu: "Japán", id: "Jepang", it: "Giappone", nl: "Japan", no: "Japan", pl: "Japonia",
    pt: "Japão", "pt-pt": "Japão", ro: "Japonia", ru: "Япония", sk: "Japonsko", sl: "Japonska", sr: "Јапан", sv: "Japan", tr: "Japonya", zh: "日本"
  },
  "Sweden": {
    en: "Sweden", "en-us": "Sweden", ar: "السويد", az: "İsveç", bn: "সুইডেন", cs: "Švédsko", da: "Sverige", de: "Schweden", el: "Σουηδία", es: "Suecia",
    "es-la": "Suecia", fr: "Suède", hi: "स्वीडन", hr: "Švedska", hu: "Svédország", id: "Swedia", it: "Svezia", nl: "Zweden", no: "Sverige", pl: "Szwecja",
    pt: "Suécia", "pt-pt": "Suécia", ro: "Suedia", ru: "Šвеция", sk: "Švédsko", sl: "Švedska", sr: "Шведска", sv: "Sverige", tr: "İsveç", zh: "瑞典"
  },
  "Tunisia": {
    en: "Tunisia", "en-us": "Tunisia", ar: "تونس", az: "Tunis", bn: "তিউনিসিয়া", cs: "Tunisko", da: "Tunesien", de: "Tunesien", el: "Τυνησία", es: "Túnez",
    "es-la": "Túnez", fr: "Tunisie", hi: "ट्यूनीशिया", hr: "Tunis", hu: "Tunézia", id: "Tunisia", it: "Tunisia", nl: "Tunesië", no: "Tunisia", pl: "Tunezja",
    pt: "Tunísia", "pt-pt": "Tunísia", ro: "Tunisia", ru: "Тунис", sk: "Tunisko", sl: "Tunizija", sr: "Тунис", sv: "Tunisien", tr: "Tunus", zh: "突尼斯"
  },
  "Belgium": {
    en: "Belgium", "en-us": "Belgium", ar: "بلجيكا", az: "Belçika", bn: "বেলজিয়াম", cs: "Belgie", da: "Belgien", de: "Belgien", el: "Βέλγιο", es: "Bélgica",
    "es-la": "Bélgica", fr: "Belgique", hi: "बेल्जियम", hr: "Belgija", hu: "Belgium", id: "Belgia", it: "Belgio", nl: "België", no: "Belgia", pl: "Belgia",
    pt: "Bélgica", "pt-pt": "Bélgica", ro: "Belgia", ru: "Бельгия", sk: "Belgicko", sl: "Belgija", sr: "Белгија", sv: "Belgien", tr: "Belçika", zh: "比利时"
  },
  "Egypt": {
    en: "Egypt", "en-us": "Egypt", ar: "مصر", az: "Misir", bn: "মিশর", cs: "Egypt", da: "Egypten", de: "Ägypten", el: "Αίγυπτος", es: "Egipto",
    "es-la": "Egipto", fr: "Égypte", hi: "मिस्र", hr: "Egipat", hu: "Egyiptom", id: "Mesir", it: "Egitto", nl: "Egypte", no: "Egypt", pl: "Egipt",
    pt: "Egito", "pt-pt": "Egito", ro: "Egipt", ru: "Египет", sk: "Egypt", sl: "Egipt", sr: "Египат", sv: "Egypten", tr: "Mısır", zh: "毁灭"
  },
  "Iran": {
    en: "Iran", "en-us": "Iran", ar: "إيران", az: "İran", bn: "ইরান", cs: "Írán", da: "Iran", de: "Iran", el: "Ιράν", es: "Irán",
    "es-la": "Irán", fr: "Iran", hi: "इरान", hr: "Iran", hu: "Irán", id: "Iran", it: "Iran", nl: "Iran", no: "Iran", pl: "Iran",
    pt: "Irã", "pt-pt": "Irão", ro: "Iran", ru: "Иран", sk: "Irán", sl: "Iran", sr: "Иран", sv: "Iran", tr: "İran", zh: "伊朗"
  },
  "New Zealand": {
    en: "New Zealand", "en-us": "New Zealand", ar: "نيوزيلندا", az: "Yeni Zelandiya", bn: "নিউজিল্যান্ড", cs: "Nový Zéland", da: "New Zealand", de: "Neuseeland", el: "Νέα Ζηλανδία", es: "Nueva Zelanda",
    "es-la": "Nueva Zelanda", fr: "Nouvelle-Zélande", hi: "न्यूजीलैंड", hr: "Novi Zeland", hu: "Új-Zéland", id: "Selandia Baru", it: "Nuova Zelanda", nl: "Nieuw-Zeeland", no: "New Zealand", pl: "Nowa Zelandia",
    pt: "Nova Zelândia", "pt-pt": "Nova Zelândia", ro: "Noua Zeelandă", ru: "Новая Зеландия", sk: "Nový Zéland", sl: "Nova Zelandija", sr: "Нови Зеланд", sv: "Nya Zeeland", tr: "Yeni Zelanda", zh: "新西兰"
  },
  "Spain": {
    en: "Spain", "en-us": "Spain", ar: "إسبانيا", az: "İspaniya", bn: "স্পেন", cs: "Španělsko", da: "Spanien", de: "Spanien", el: "Ισπανία", es: "España",
    "es-la": "España", fr: "Espagne", hi: "स्पेन", hr: "Španjolska", hu: "Spanyolország", id: "Spanyol", it: "Spagna", nl: "Spanje", no: "Spania", pl: "Hiszpania",
    pt: "Espanha", "pt-pt": "Espanha", ro: "Spania", ru: "Испания", sk: "Španielsko", sl: "Španija", sr: "Шпанија", sv: "Spanien", tr: "İspanya", zh: "西班牙"
  },
  "Cape Verde": {
    en: "Cape Verde", "en-us": "Cabo Verde", ar: "الرأس الأخضر", az: "Kabo-Verde", bn: "কেপ ভার্দে", cs: "Kapverdy", da: "Kap Verde", de: "Kap Verde", el: "Πράσινο Ακρωτήριο", es: "Cabo Verde",
    "es-la": "Cabo Verde", fr: "Cap-Vert", hi: "केप वर्डे", hr: "Zelenortska Republika", hu: "Zöld-foki Köztársaság", id: "Tanjung Verde", it: "Capo Verde", nl: "Kaapverdië", no: "Kapp Verde", pl: "Republika Zielonego Przylądka",
    pt: "Cabo Verde", "pt-pt": "Cabo Verde", ro: "Cabo Verde", ru: "Кабо-Верде", sk: "Kapverdy", sl: "Zelenortski otoki", sr: "Зеленортска Острва", sv: "Kap Verde", tr: "Yeşil Burun Adaları", zh: "佛得角"
  },
  "Saudi Arabia": {
    en: "Saudi Arabia", "en-us": "Saudi Arabia", ar: "المملكة العربية السعودية", az: "Səudiyyə Ərəbistanı", bn: "সৌদি আরব", cs: "Saúdská Arábie", da: "Saudi-Arabien", de: "Saudi-Arabien", el: "Σαουδική Αραβία", es: "Arabia Saudita",
    "es-la": "Arabia Saudita", fr: "Arabie Saoudite", hi: "सऊदी अरब", hr: "Saudijska Arabija", hu: "Szaúd-Arábia", id: "Arab Saudi", it: "Arabia Saudita", nl: "Saudi-Arabië", no: "Saudi-Arabia", pl: "Arabia Saudyjska",
    pt: "Arábia Saudita", "pt-pt": "Arábia Saudita", ro: "Arabia Saudită", ru: "Саудовская Аравия", sk: "Saudská Arábia", sl: "Saudova Arabija", sr: "Саудијска Арабија", sv: "Saudiarabien", tr: "Suudi Arabistan", zh: "沙特阿拉伯"
  },
  "Uruguay": {
    en: "Uruguay", "en-us": "Uruguay", ar: "أوروغواي", az: "Uruqvay", bn: "উরুগুয়ে", cs: "Uruguay", da: "Uruguay", de: "Uruguay", el: "Ουρουγουάη", es: "Uruguay",
    "es-la": "Uruguay", fr: "Uruguay", hi: "उरुग्वे", hr: "Urugvaj", hu: "Uruguay", id: "Uruguay", it: "Uruguay", nl: "Uruguay", no: "Uruguay", pl: "Urugwaj",
    pt: "Uruguai", "pt-pt": "Uruguai", ro: "Uruguay", ru: "Уругвай", sk: "Urugvaj", sl: "Urugvaj", sr: "Уругвај", sv: "Uruguay", tr: "Uruguay", zh: "乌拉圭"
  },
  "France": {
    en: "France", "en-us": "France", ar: "فرنسا", az: "Fransa", bn: "ফ্রান্স", cs: "Francie", da: "Frankrig", de: "Frankreich", el: "Γαλλία", es: "Francia",
    "es-la": "Francia", fr: "France", hi: "फ़्रांस", hr: "Francuska", hu: "Franciaország", id: "Prancis", it: "Francia", nl: "Frankrijk", no: "Frankrike", pl: "Francja",
    pt: "França", "pt-pt": "França", ro: "Franța", ru: "Франция", sk: "Francúzsko", sl: "Francija", sr: "Француска", sv: "Frankrike", tr: "Fransa", zh: "法国"
  },
  "Senegal": {
    en: "Senegal", "en-us": "Senegal", ar: "السنغال", az: "Seneqal", bn: "সেনেগাল", cs: "Senegal", da: "Senegal", de: "Senegal", el: "Σενεγάλη", es: "Senegal",
    "es-la": "Senegal", fr: "Sénégal", hi: "सेनेगल", hr: "Senegal", hu: "Szenegál", id: "Senegal", it: "Senegal", nl: "Senegal", no: "Senegal", pl: "Senegal",
    pt: "Senegal", "pt-pt": "Senegal", ro: "Senegal", ru: "Сенегал", sk: "Senegal", sl: "Senegal", sr: "Сенегал", sv: "Senegal", tr: "Senegal", zh: "塞内加尔"
  },
  "Iraq": {
    en: "Iraq", "en-us": "Iraq", ar: "العراق", az: "İraq", bn: "ইরাক", cs: "Irák", da: "Irak", de: "Irak", el: "Ιράκ", es: "Irak",
    "es-la": "Irak", fr: "Irak", hi: "इराक", hr: "Irak", hu: "Irak", id: "Irak", it: "Iraq", nl: "Irak", no: "Irak", pl: "Irak",
    pt: "Iraque", "pt-pt": "Iraque", ro: "Irak", ru: "Ирак", sk: "Irak", sl: "Irak", sr: "Ирак", sv: "Irak", tr: "Irak", zh: "伊拉克"
  },
  "Norway": {
    en: "Norway", "en-us": "Norway", ar: "النرويج", az: "Norveç", bn: "নরওয়ে", cs: "Norsko", da: "Norge", de: "Norwegen", el: "Νορβηγία", es: "Noruega",
    "es-la": "Noruega", fr: "Norvège", hi: "नॉर्वे", hr: "Norveška", hu: "Norvégia", id: "Norwegia", it: "Norvegia", nl: "Noorwegen", no: "Norge", pl: "Norwegia",
    pt: "Noruega", "pt-pt": "Noruega", ro: "Norvegia", ru: "Норвегия", sk: "Nórsko", sl: "Norveška", sr: "Норвешка", sv: "Norge", tr: "Norveç", zh: "挪威"
  },
  "Argentina": {
    en: "Argentina", "en-us": "Argentina", ar: "الأرجنتين", az: "Argentina", bn: "আর্জেন্টিনা", cs: "Argentina", da: "Argentina", de: "Argentinien", el: "Αργεντινή", es: "Argentina",
    "es-la": "Argentina", fr: "Argentine", hi: "अर्जेण्टीना", hr: "Argentina", hu: "Argentína", id: "Argentina", it: "Argentina", nl: "Argentinië", no: "Argentina", pl: "Argentyna",
    pt: "Argentina", "pt-pt": "Argentina", ro: "Argentina", ru: "Аргентина", sk: "Argentína", sl: "Argentina", sr: "Аргентина", sv: "Argentina", tr: "Arjantin", zh: "阿根廷"
  },
  "Algeria": {
    en: "Algeria", "en-us": "Algeria", ar: "الجزائر", az: "Əlcəzair", bn: "আলজেরিয়া", cs: "Alžírsko", da: "Algeriet", de: "Algerien", el: "Αλγερία", es: "Argelia",
    "es-la": "Argelia", fr: "Algérie", hi: "अल्जीरिया", hr: "Alžir", hu: "Algéria", id: "Aljazair", it: "Algeria", nl: "Algerije", no: "Algerie", pl: "Algieria",
    pt: "Argélia", "pt-pt": "Argélia", ro: "Algeria", ru: "Алжир", sk: "Alžírsko", sl: "Alžirija", sr: "Алжир", sv: "Algeriet", tr: "Cezayir", zh: "阿尔及利亚"
  },
  "Austria": {
    en: "Austria", "en-us": "Austria", ar: "النمسا", az: "Avstriya", bn: "অস্ট্রিয়া", cs: "Rakousko", da: "Østrig", de: "Österreich", el: "Αυστρία", es: "Austria",
    "es-la": "Austria", fr: "Autriche", hi: "ऑस्ट्रिया", hr: "Austrija", hu: "Ausztria", id: "Austria", it: "Austria", nl: "Oostenrijk", no: "Østerrike", pl: "Austria",
    pt: "Áustria", "pt-pt": "Áustria", ro: "Austria", ru: "Австрия", sk: "Rakúsko", sl: "Avstrija", sr: "Аустрија", sv: "Österrike", tr: "Avusturya", zh: "奥地利"
  },
  "Jordan": {
    en: "Jordan", "en-us": "Jordan", ar: "الأردن", az: "İordaniya", bn: "জর্ডান", cs: "Jordánsko", da: "Jordan", de: "Jordanien", el: "Ιορδανία", es: "Jordania",
    "es-la": "Jordania", fr: "Jordanie", hi: "जॉर्डन", hr: "Jordan", hu: "Jordánia", id: "Yordania", it: "Giordania", nl: "Jordanië", no: "Jordan", pl: "Jordania",
    pt: "Jordânia", "pt-pt": "Jordânia", ro: "Iordania", ru: "Иордания", sk: "Jordánsko", sl: "Jordanija", sr: "Јордан", sv: "Jordanien", tr: "Ürdün", zh: "约旦"
  },
  "Portugal": {
    en: "Portugal", "en-us": "Portugal", ar: "البرتغال", az: "Portuqaliya", bn: "পর্তুগাল", cs: "Portugalsko", da: "Portugal", de: "Portugal", el: "Πορτογαλία", es: "Portugal",
    "es-la": "Portugal", fr: "Portugal", hi: "पुर्तगाल", hr: "Portugal", hu: "Portugália", id: "Portugal", it: "Portogallo", nl: "Portugal", no: "Portugal", pl: "Portugalia",
    pt: "Portugal", "pt-pt": "Portugal", ro: "Portugalia", ru: "Португалия", sk: "Portugalsko", sl: "Portugalska", sr: "Португалија", sv: "Portugal", tr: "Portekiz", zh: "葡萄牙"
  },
  "Democratic Republic of the Congo": {
    en: "DR Congo", "en-us": "DR Congo", ar: "جمهورية الكونغو الديمقراطية", az: "Konqo Demokratik Respublikası", bn: "গণতান্ত্রিক কঙ্গো প্রজাতন্ত্র", cs: "DR Kongo", da: "DR Congo", de: "DR Kongo", el: "Λαϊκή Δημοκρατία του Кονγκό", es: "República Democrática del Congo",
    "es-la": "República Democrática del Congo", fr: "RD Congo", hi: "कांगो लोकतांत्रिक गणराज्य", hr: "DR Kongo", hu: "Kongói Demokratikus Köztársaság", id: "Republik Demokratik Kongo", it: "Repubblica Democratica del Congo", nl: "Congo-Kinshasa", no: "DR Kongo", pl: "Demokratyczna Republika Konga",
    pt: "RD Congo", "pt-pt": "RD Congo", ro: "RD Congo", ru: "ДР Конго", sk: "DR Kongo", sl: "Demokratična republika Kongo", sr: "ДР Конго", sv: "Kongo-Kinshasa", tr: "Demokratik Kongo Cumhuriyeti", zh: "民主刚果"
  },
  "Uzbekistan": {
    en: "Uzbekistan", "en-us": "Uzbekistan", ar: "أوزبكستان", az: "Özbəkistan", bn: "উজবেকিস্তান", cs: "Uzbekistán", da: "Usbekistan", de: "Usbekistan", el: "Ουζμπεκιστάν", es: "Uzbekistán",
    "es-la": "Uzbekistán", fr: "Ouzbékistan", hi: "उज़्बेकिस्तान", hr: "Uzbekistan", hu: "Üzbegisztán", id: "Uzbekistan", it: "Uzbekistan", nl: "Oezbekistan", no: "Usbekistan", pl: "Uzbekistan",
    pt: "Uzbequistão", "pt-pt": "Uzbequistão", ro: "Uzbekistan", ru: "Узбекистан", sk: "Uzbekistan", sl: "Uzbekistan", sr: "Узбекистан", sv: "Uzbekistan", tr: "Özbekistan", zh: "乌兹别克斯坦"
  },
  "Colombia": {
    en: "Colombia", "en-us": "Colombia", ar: "كولومبيا", az: "Kolumbiya", bn: "কলম্বিয়া", cs: "Kolumbie", da: "Colombia", de: "Kolumbien", el: "Κολομβία", es: "Colombia",
    "es-la": "Colombia", fr: "Colombie", hi: "कोलंबिया", hr: "Kolumbija", hu: "Kolumbia", id: "Kolombia", it: "Colombia", nl: "Colombia", no: "Colombia", pl: "Kolumbia",
    pt: "Colômbia", "pt-pt": "Colômbia", ro: "Columbia", ru: "Колумбия", sk: "Kolumbia", sl: "Kolumbija", sr: "Колумбија", sv: "Colombia", tr: "Kolombiya", zh: "哥伦比亚"
  },
  "England": {
    en: "England", "en-us": "England", ar: "إنجلترا", az: "İngiltərə", bn: "ইংল্যান্ড", cs: "Anglie", da: "England", de: "England", el: "Αγγλία", es: "Inglaterra",
    "es-la": "Inglaterra", fr: "Angleterre", hi: "इंग्लैंड", hr: "Engleska", hu: "Anglia", id: "Inggris", it: "Inghilterra", nl: "Engeland", no: "England", pl: "Anglia",
    pt: "Inglaterra", "pt-pt": "Inglaterra", ro: "Anglia", ru: "Англия", sk: "Anglicko", sl: "Anglija", sr: "Енглеска", sv: "England", tr: "İngiltere", zh: "英格兰"
  },
  "Croatia": {
    en: "Croatia", "en-us": "Croatia", ar: "كرواتيا", az: "Xorvatiya", bn: "ক্রোয়েশিয়া", cs: "Chorvatsko", da: "Kroatien", de: "Kroatien", el: "Κροατία", es: "Croacia",
    "es-la": "Croacia", fr: "Croatie", hi: "क्रोएशिया", hr: "Hrvatska", hu: "Horvátország", id: "Kroasia", it: "Croazia", nl: "Kroatië", no: "Kroatia", pl: "Chorwacja",
    pt: "Croácia", "pt-pt": "Croácia", ro: "Croația", ru: "Хорватия", sk: "Chorvátsko", sl: "Hrvaška", sr: "Хрватска", sv: "Kroatien", tr: "Hırvatistan", zh: "克罗地亚"
  },
  "Ghana": {
    en: "Ghana", "en-us": "Ghana", ar: "غانا", az: "Qana", bn: "ঘানা", cs: "Ghana", da: "Ghana", de: "Ghana", el: "Γκάνα", es: "Ghana",
    "es-la": "Ghana", fr: "Ghana", hi: "घाना", hr: "Gana", hu: "Ghána", id: "Ghana", it: "Ghana", nl: "Ghana", no: "Ghana", pl: "Ghana",
    pt: "Gana", "pt-pt": "Gana", ro: "Ghana", ru: "Гана", sk: "Ghana", sl: "Gana", sr: "Гана", sv: "Ghana", tr: "Gana", zh: "加纳"
  },
  "Panama": {
    en: "Panama", "en-us": "Panama", ar: "بنما", az: "Panama", bn: "পানামা", cs: "Panama", da: "Panama", de: "Panama", el: "Παναμάς", es: "Panamá",
    "es-la": "Panamá", fr: "Panama", hi: "पनामा", hr: "Panama", hu: "Panama", id: "Panama", it: "Panama", nl: "Panama", no: "Panama", pl: "Panama",
    pt: "Panamá", "pt-pt": "Panamá", ro: "Panama", ru: "Панама", sk: "Panama", sl: "Panama", sr: "Панама", sv: "Panama", tr: "Panama", zh: "巴拿马"
  }
}

export const stadiumTranslations: Record<string, Partial<Record<LanguageCode, string>>> = {
  "Estadio Azteca": {
    en: "Estadio Azteca, Mexico City", ar: "ملعب أزتيكا، مكسيكو سيتي", es: "Estadio Azteca, Ciudad de México", pt: "Estádio Azteca, Cidade do México",
    ru: "Стадион Ацтека, Мехико", zh: "阿兹特克体育场，墨西哥城", bn: "এস্তাদিও অ্যাজটেকা, মেক্সিকো সিটি", tr: "Azteka Stadyumu, Meksiko",
    de: "Aztekenstadion, Mexiko-Stadt", fr: "Stade Azteca, Mexico", it: "Stadio Azteca, Città del Messico", nl: "Aztekenstadion, Mexico-Stad"
  },
  "Estadio Akron": {
    en: "Estadio Akron, Guadalajara", ar: "ملعب أكرون، غوادالاخارا", es: "Estadio Akron, Guadalajara", pt: "Estádio Akron, Guadalajara",
    ru: "Стадион Акрон, Гвадалахара", zh: "阿克伦体育场，瓜达拉哈拉", bn: "এস্তাদিও আকরন, গুয়াডالاহারা", tr: "Akron Stadyumu, Guadalajara",
    de: "Akron Stadion, Guadalajara", fr: "Stade Akron, Guadalajara", it: "Stadio Akron, Guadalajara", nl: "Akron Stadion, Guadalajara"
  },
  "Estadio BBVA": {
    en: "Estadio BBVA, Monterrey", ar: "ملعب بي بي في ايه، مونتيري", es: "Estadio BBVA, Monterrey", pt: "Estádio BBVA, Monterrey",
    ru: "Стадион BBVA, Монтеррей", zh: "BBVA体育场，蒙特雷", bn: "এস্তাদিও বিবিভিএ, মন্টেরি", tr: "BBVA Stadyumu, Monterrey",
    de: "BBVA Stadion, Monterrey", fr: "Stade BBVA, Monterrey", it: "Stadio BBVA, Monterrey", nl: "BBVA Stadion, Monterrey"
  },
  "AT&T Stadium": {
    en: "AT&T Stadium, Dallas", ar: "ملعب إيه تي أند تي، دالاس", es: "Estadio AT&T, Dallas", pt: "Estádio AT&T, Dallas",
    ru: "Стадион AT&T, Даллас", zh: "AT&T体育场，达拉斯", bn: "এটিঅ্যান্ডটি স্টেডিয়াম, ডালাস", tr: "AT&T Stadyumu, Dallas",
    de: "AT&T Stadion, Dallas", fr: "Stade AT&T, Dallas", it: "Stadio AT&T, Dallas", nl: "AT&T Stadion, Dallas"
  },
  "NRG Stadium": {
    en: "NRG Stadium, Houston", ar: "ملعب إن آر جي، هيوستن", es: "Estadio NRG, Houston", pt: "Estádio NRG, Houston",
    ru: "Стадион NRG, Хьюстон", zh: "NRG体育场，休斯敦", bn: "এনআরজি স্টেডিয়াম, হিউস্টน", tr: "NRG Stadyumu, Houston",
    de: "NRG Stadion, Houston", fr: "Stade NRG, Houston", it: "Stadio NRG, Houston", nl: "NRG Stadion, Houston"
  },
  "GEHA Field at Arrowhead Stadium": {
    en: "Arrowhead Stadium, Kansas City", ar: "ملعب أروهيد، كانساس سيتي", es: "Estadio Arrowhead, Kansas City", pt: "Estádio Arrowhead, Kansas City",
    ru: "Стадион Эрроухед, Канзас-Сити", zh: "箭头体育场，堪萨斯城", bn: "অ্যারোহেড স্টেডিয়াম, কানসাস সিটি", tr: "Arrowhead Stadyumu, Kansas City",
    de: "Arrowhead Stadion, Kansas City", fr: "Stade Arrowhead, Kansas City", it: "Stadio Arrowhead, Kansas City", nl: "Arrowhead Stadion, Kansas City"
  },
  "Mercedes-Benz Stadium": {
    en: "Mercedes-Benz Stadium, Atlanta", ar: "ملعب مرسيدس بنز، أتلانتا", es: "Estadio Mercedes-Benz, Atlanta", pt: "Estádio Mercedes-Benz, Atlanta",
    ru: "Стадион Мерседес-Бенц, Атланта", zh: "梅赛德斯-奔驰体育场，亚特兰大", bn: "মার্সিডিজ-বেঞ্জ স্টেডিয়াম, আটলান্টা", tr: "Mercedes-Benz Stadyumu, Atlanta",
    de: "Mercedes-Benz Stadion, Atlanta", fr: "Stade Mercedes-Benz, Atlanta", it: "Stadio Mercedes-Benz, Atlanta", nl: "Mercedes-Benz Stadion, Atlanta"
  },
  "Hard Rock Stadium": {
    en: "Hard Rock Stadium, Miami", ar: "ملعب هارد روك، ميامي", es: "Estadio Hard Rock, Miami", pt: "Estádio Hard Rock, Miami",
    ru: "Стадион Хард Рок, Майами", zh: "硬石体育场，迈阿密", bn: "হার্ড রক স্টেডিয়াম, মায়ামি", tr: "Hard Rock Stadyumu, Miami",
    de: "Hard Rock Stadion, Miami", fr: "Stade Hard Rock, Miami", it: "Stadio Hard Rock, Miami", nl: "Hard Rock Stadion, Miami"
  },
  "Gillette Stadium": {
    en: "Gillette Stadium, Boston", ar: "ملعب جيليت، بوسطن", es: "Estadio Gillette, Boston", pt: "Estádio Gillette, Boston",
    ru: "Стадион Джиллетт, Бостон", zh: "吉列体育场，波士顿", bn: "জিলেট স্টেডিয়াম, বোস্টন", tr: "Gillette Stadyumu, Boston",
    de: "Gillette Stadion, Boston", fr: "Stade Gillette, Boston", it: "Stadio Gillette, Boston", nl: "Gillette Stadion, Boston"
  },
  "Lincoln Financial Field": {
    en: "Lincoln Financial Field, Philadelphia", ar: "ملعب لينكون فاينانشال، فيلادلفيا", es: "Lincoln Financial Field, Filadelfia", pt: "Lincoln Financial Field, Filadélfia",
    ru: "Линкольн Файненшел Филд, Филадельфия", zh: "林肯金融体育场，费城", bn: "লিংকন ফাইন্যান্সিয়াল ফিল্ড, ফিলাডেলফিয়া", tr: "Lincoln Financial Field, Philadelphia",
    de: "Lincoln Financial Field, Philadelphia", fr: "Stade Lincoln Financial Field, Philadelphie", it: "Lincoln Financial Field, Filadelfia", nl: "Lincoln Financial Field, Philadelphia"
  },
  "MetLife Stadium": {
    en: "MetLife Stadium, New York", ar: "ملعب ميتلايف، نيويورك", es: "Estadio MetLife, Nueva York", pt: "Estádio MetLife, Nova York",
    ru: "Стадион Метлайф, Нью-Йорк", zh: "大都会人寿体育场，纽约", bn: "মেটলাইফ স্টেডিয়াম, নিউ ইয়র্ক", tr: "MetLife Stadyumu, New York",
    de: "MetLife Stadion, New York", fr: "Stade MetLife, New York", it: "Stadio MetLife, New York", nl: "MetLife Stadion, New York"
  },
  "BMO Field": {
    en: "BMO Field, Toronto", ar: "ملعب بي إم أو، تورونتو", es: "BMO Field, Toronto", pt: "BMO Field, Toronto",
    ru: "БМО Филд, Торонто", zh: "BMO球场，多伦多", bn: "বিএমও ফিল্ড, টরন্টো", tr: "BMO Field, Toronto",
    de: "BMO Field, Toronto", fr: "Stade BMO Field, Toronto", it: "BMO Field, Toronto", nl: "BMO Field, Toronto"
  },
  "BC Place": {
    en: "BC Place, Vancouver", ar: "ملعب بي سي بليس، فانكوفر", es: "BC Place, Vancouver", pt: "BC Place, Vancouver",
    ru: "Би-Си Плэйс, Ванкувер", zh: "BC Place体育场，温哥华", bn: "বিসি প্লেস, ভ্যাঙ্কুভার", tr: "BC Place, Vancouver",
    de: "BC Place, Vancouver", fr: "Stade BC Place, Vancouver", it: "BC Place, Vancouver", nl: "BC Place, Vancouver"
  },
  "Lumen Field": {
    en: "Lumen Field, Seattle", ar: "ملعب لومن، سياتل", es: "Estadio Lumen Field, Seattle", pt: "Estádio Lumen Field, Seattle",
    ru: "Люмен Филд, Сиэтл", zh: "流明体育场，西雅图", bn: "লুমেন ফিল্ড, সিয়াটল", tr: "Lumen Field, Seattle",
    de: "Lumen Field, Seattle", fr: "Stade Lumen Field, Seattle", it: "Stadio Lumen Field, Seattle", nl: "Lumen Field, Seattle"
  },
  "Levi's Stadium": {
    en: "Levi's Stadium, San Francisco", ar: "ملعب ليفايز، سان فرانسيسكو", es: "Estadio Levi's, San Francisco", pt: "Estádio Levi's, São Francisco",
    ru: "Ливайс Стэдиум, Сан-Франциско", zh: "利维斯体育场，旧金山", bn: "লিভাইস স্টেডিয়াম, সান ফ্রান্সিসকো", tr: "Levi's Stadyumu, San Francisco",
    de: "Levi's Stadion, San Francisco", fr: "Stade Levi's, San Francisco", it: "Stadio Levi's, San Francisco", nl: "Levi's Stadion, San Francisco"
  },
  "SoFi Stadium": {
    en: "SoFi Stadium, Los Angeles", ar: "ملعب سوفي، لوس أنجلوس", es: "Estadio SoFi, Los Ángeles", pt: "Estádio SoFi, Los Angeles",
    ru: "Соу-Фай Стэдиум, Лос-Анджелес", zh: "SoFi体育场，洛杉矶", bn: "সোফাই স্টেডিয়াম, লস অ্যাঞ্জেলেস", tr: "SoFi Stadyumu, Los Angeles",
    de: "SoFi Stadion, Los Angeles", fr: "Stade SoFi, Los Angeles", it: "Stadio SoFi, Los Angeles", nl: "SoFi Stadion, Los Angeles"
  }
}
